defmodule PeanutButterShoppeWeb.UserSettingsView do
  use PeanutButterShoppeWeb, :view
end
