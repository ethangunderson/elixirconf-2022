defmodule PeanutButterShoppeWeb.UserConfirmationView do
  use PeanutButterShoppeWeb, :view
end
