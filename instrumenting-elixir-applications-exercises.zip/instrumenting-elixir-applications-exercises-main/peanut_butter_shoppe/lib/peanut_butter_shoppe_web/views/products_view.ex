defmodule PeanutButterShoppeWeb.ProductsView do
  use PeanutButterShoppeWeb, :view
end
