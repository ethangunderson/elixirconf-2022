defmodule PeanutButterShoppeWeb.UserResetPasswordView do
  use PeanutButterShoppeWeb, :view
end
