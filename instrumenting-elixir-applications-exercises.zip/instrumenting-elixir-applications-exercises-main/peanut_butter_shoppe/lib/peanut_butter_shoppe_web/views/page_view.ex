defmodule PeanutButterShoppeWeb.PageView do
  use PeanutButterShoppeWeb, :view
end
