defmodule PeanutButterShoppeWeb.UserSessionView do
  use PeanutButterShoppeWeb, :view
end
