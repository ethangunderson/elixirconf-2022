defmodule PeanutButterShoppeWeb.UserRegistrationView do
  use PeanutButterShoppeWeb, :view
end
