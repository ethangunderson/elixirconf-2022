defmodule PeanutButterShoppeWeb.OrdersController do
  use PeanutButterShoppeWeb, :controller

  import PeanutButterShoppeWeb.UserAuth, only: [fetch_current_user: 2]

  alias PeanutButterShoppe.Orders

  plug :fetch_current_user

  def create(%{assigns: %{current_user: current_user}} = conn, _params) do
    case Orders.submit(%{user_id: current_user.id}) do
      {:ok, _order} ->
        conn
        |> put_flash(:info, "Order submitted successfully")
        |> redirect(to: Routes.page_path(conn, :index))

      {:error, _changeset} ->
        conn
        |> put_flash(:warning, "Failed to submit order")
        |> redirect(to: Routes.page_path(conn, :index))
    end
  end
end
