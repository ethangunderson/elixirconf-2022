defmodule PeanutButterShoppeWeb.PageController do
  use PeanutButterShoppeWeb, :controller

  alias PeanutButterShoppe.Products

  def index(conn, _params) do
    conn
    |> assign(:products, Products.list())
    |> render("index.html")
  end
end
