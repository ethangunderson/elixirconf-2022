defmodule PeanutButterShoppeWeb.ProductsController do
  use PeanutButterShoppeWeb, :controller

  alias PeanutButterShoppe.Products

  # require OpenTelemetry.Tracer, as: Tracer
  # use OpenTelemetryDecorator

  def show(conn, %{"id" => id}) do
    case Products.find(id) do
      nil ->
        redirect(conn, to: Routes.page_path(conn, :index))

      product ->
        track_product_show_in_analytics(product.id)

        conn
        |> assign(:product, product)
        |> render("show.html")
    end
  end

  defp track_product_show_in_analytics(_product_id) do
    # TODO Use `Tracer.with_span` to wrap this function's body in a span. Give the span a name that matches the function name and arity.
    Req.request(method: :get, url: "https://httpstat.us/200?sleep=#{:rand.uniform(5000)}")
  end
end
