defmodule PeanutButterShoppeWeb.Components.Button do
  use Phoenix.Component

  def button(assigns) do
    assigns =
      assigns
      |> assign_new(:fathom_event_code, fn -> nil end)
      |> assign_new(:link_type, fn -> "link" end)
      |> assign_new(:to, fn -> "" end)
      |> assign_new(:classes, fn -> button_classes() end)

    ~H"""
    <.custom_link to={@to} label={@label} link_type={@link_type} classes={@classes} />
    """
  end

  def button_classes do
    ["font-medium text-lg bg-amber-800 text-gray-50 px-5 py-3 rounded-sm"]
  end

  def custom_link(%{link_type: "link"} = assigns) do
    ~H"""
    <%= Phoenix.HTML.Link.link(
      [
        to: @to,
        class: @classes
      ],
      do: @label
    ) %>
    """
  end

  def custom_link(%{link_type: "button"} = assigns) do
    ~H"""
    <button class={@classes}><%= @label %></button>
    """
  end
end
