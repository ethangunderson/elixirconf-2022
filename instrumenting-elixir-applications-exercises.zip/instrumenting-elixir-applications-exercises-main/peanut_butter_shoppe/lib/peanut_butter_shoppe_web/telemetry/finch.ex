defmodule PeanutButterShoppeWeb.Telemetry.Finch do
  @moduledoc """
  Telemetry handlers for Finch requests. Full Finch Telemetry documentation can be found here: https://hexdocs.pm/finch/Finch.Telemetry.html
  """

  require OpenTelemetry.Tracer, as: Tracer

  def attach do
    :telemetry.attach(
      {__MODULE__, [:finch, :start]},
      [:finch, :request, :start],
      &__MODULE__.start_span/4,
      nil
    )

    :telemetry.attach(
      {__MODULE__, [:finch, :stop]},
      [:finch, :request, :stop],
      &__MODULE__.stop_span/4,
      nil
    )
  end

  def start_span(_event, _measurements, %{request: request} = metadata, _config) do
    # NOTE: Finch's Telemetry event documentation can be found here: https://hexdocs.pm/finch/Finch.Telemetry.html
    # TODO: Create an attributes map using the finch request found in the metadata. Set "http.method" to the request method, "http.host" to the request host, and "http.path" to the request path.

    # TODO: Get the existing span context using `OpenTelemetry.Ctx.get_current()`. 
    # parent_context = OpenTelemetry.Ctx.get_current()

    # TODO: Start a new span with the context above. The span should be named "HTTP Request". Provide the attributes map constructed above.

    # TODO: Use `Tracer.set_current_span` so set the new span as the current span.
  end

  def stop_span(_event, _measurements, _metadata, _config) do
    # TODO: End the current span using `Tracer.end_span`
  end
end
