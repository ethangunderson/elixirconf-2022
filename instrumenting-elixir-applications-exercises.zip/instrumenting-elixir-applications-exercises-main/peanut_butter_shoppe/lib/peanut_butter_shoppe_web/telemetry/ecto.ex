defmodule PeanutButterShoppeWeb.Telemetry.Ecto do
  require OpenTelemetry.Tracer, as: Tracer

  def attach() do
    :telemetry.attach(
      {__MODULE__, {:repo, :query}},
      [:peanut_butter_shoppe, :repo, :query],
      &__MODULE__.handle_event/4,
      nil
    )
  end

  def handle_event(_event, measurements, metadata, _config) do
    # TODO: Since this event is executed after query completion, we need to work our way back to figure out the true start time of the span. Using `measurements.total_time` and `OpenTelemetry.timestamp()`, get the approximate start time for the span. Set it to `start_time`.

    # TODO: Construct an attributes map for the span. Set `db.type` to :sql, `db.statement` to the query found in metadata, `source` as the source found in metadata, and `total_time` as the total_time found in the measurements converted to `microseconds` using `System.convert_time_unit`. 

    # TODO: Get the existing span context using `OpenTelemetry.Ctx.get_current()`. This will be the span created by Phoenix Telemetry and we can use this as the parent of the span we will create next.

    # TODO: Start a new span with the context above. The span should be named "query". In the options argument provide a `start_time`, a `kind` of `:sql`, and the attributes map constructed above.

    # TODO: Close the span using `OpenTelemetry.Span.end_span(span)`
  end
end
