defmodule PeanutButterShoppeWeb.Telemetry.Phoenix do
  require OpenTelemetry.Tracer, as: Tracer

  @doc """
  This function will attach to Phoenix telemetry events in order to allow
  spans to be generated. It is called from PeanutButterShoppe.Application
  """
  def attach do
    :telemetry.attach(
      {__MODULE__, :endpoint_start},
      [:phoenix, :endpoint, :start],
      &__MODULE__.handle_start_event/4,
      nil
    )

    :telemetry.attach(
      {__MODULE__, :dispatch_start},
      [:phoenix, :router_dispatch, :start],
      &__MODULE__.handle_router_event/4,
      nil
    )

    :telemetry.attach(
      {__MODULE__, :endpoint_stop},
      [:phoenix, :endpoint, :stop],
      &__MODULE__.handle_stop_event/4,
      nil
    )
  end

  def handle_start_event(_event, _measurement, %{conn: conn} = _metadata, _config) do
    # TODO: Open a span using `Tracer.start_span`. Set the name as "HTTP method". Include a map of 
    # attributes, %{attributes: %{}}, including "http.method" and "http.target" with values pulled from the conn.
    # TODO: Use the result of `start_span` to set the current span with `Tracer.set_current_span()`
    # NOTE: The docs for OpenTelemetry.Tracer can be found here: https://hexdocs.pm/opentelemetry_api/OpenTelemetry.Tracer.html
    # NOTE: The docs for Conn can be found here: https://hexdocs.pm/plug/Plug.Conn.html
  end

  def handle_router_event(_event, _measurement, %{conn: conn} = metadata, _config) do
    # TODO: Update the span name with `update_name` in the format of "METHOD ROUTE"
  end

  def handle_stop_event(_event, _measurement, %{conn: conn} = _metadata, _config) do
    # TODO: Update the "http.status_code" attribute with the status from the conn using `Tracer.set_attribute()`
    # TODO: End the span using `Tracer.end_span()`
  end
end
