defmodule PeanutButterShoppeWeb.Telemetry.Oban do
  require OpenTelemetry.Tracer, as: Tracer

  def attach do
    :telemetry.attach(
      {__MODULE__, [:oban, :start]},
      [:oban, :job, :start],
      &__MODULE__.start_trace/4,
      nil
    )

    :telemetry.attach(
      {__MODULE__, [:oban, :stop]},
      [:oban, :job, :stop],
      &__MODULE__.stop_trace/4,
      nil
    )
  end

  def start_trace(_event, _measurements, %{job: job} = _metadata, _config) do
    # TODO: Construct an attributes map for the span. Set the priority, attempt, max attemps, and args based on the representative values in the job found in the event metadata.

    # TODO: Start a new span with the name of Oban and the name of the worker. The name of the worker can be found in the job on the metadata. Add the attributes map constructed above.

    # TODO: Set the current span to the newly created span using `Tracer.set_current_span()`.
  end

  def stop_trace(_event, _measurements, _metadata, _config) do
    # TODO: Close the span using `Tracer.end_span()`
  end
end
