defmodule PeanutButterShoppeWeb.Telemetry do
  use Supervisor
  import Telemetry.Metrics

  # Poll every 10 seconds by default
  @default_period :timer.seconds(10)
  @poller_period Application.compile_env(:peanut_butter_shoppe, :poller_period, @default_period)

  def start_link(arg) do
    Supervisor.start_link(__MODULE__, arg, name: __MODULE__)
  end

  @doc """
  Kills the Telemetry process to ease picking up new metrics.

  DO NOT DEFINE A FUNCTION THAT DOES THIS IN A PRODUCTION APP!
  """
  def restart do
    __MODULE__
    |> Process.whereis()
    |> Process.exit(:kill)
  end

  @impl true
  def init(_arg) do
    children = [
      # Telemetry poller will execute the given period measurements
      # every 10_000ms. Learn more here: https://hexdocs.pm/telemetry_metrics
      {:telemetry_poller, measurements: periodic_measurements(), period: @poller_period},

      # We have installed the TelemetryMetricsStatsd reporter.
      # This line starts the reporter and directs it to report on the
      # metrics defined in our `metrics/0` function below. This reporter
      # will handle collecting these metrics and sending them over UDP
      # to Statsd. Our job is to choose which metrics we want in the
      # `metrics/0` function.
      {TelemetryMetricsStatsd, metrics: metrics()}
    ]

    Supervisor.init(children, strategy: :one_for_one)
  end

  def metrics do
    vm_metrics()
    |> Enum.concat(phoenix_metrics())
    |> Enum.concat(database_metrics())
    |> Enum.concat(business_metrics())
    |> Enum.concat(supplemental_vm_metrics())
  end

  # EXERCISE Section 1: VM Metrics.
  @spec vm_metrics() :: list()
  defp vm_metrics do
    []
  end

  # EXERCISE Section 2: Phoenix Metrics
  @spec phoenix_metrics() :: list()
  defp phoenix_metrics do
    []
  end

  # EXERCISE Section 3: Ecto & Database Metrics
  @spec database_metrics() :: list()
  defp database_metrics do
    []
  end

  # EXERCISE Section 4: Custom Business Metrics
  @spec business_metrics() :: list()
  defp business_metrics do
    []
  end

  # EXERCISE Section 5: Supplemental VM Metrics
  @spec dispatch_measurements() :: :ok
  def dispatch_measurements do
  end

  # EXERCISE SECTION 6: Periodic Business Metrics
  @spec dispatch_business_measurements() :: :ok
  def dispatch_business_measurements do
  end

  @spec supplemental_vm_metrics() :: list()
  defp supplemental_vm_metrics do
    []
  end

  # EXERCISE Section 6: Periodic Metric Measurements
  @spec periodic_measurements() :: list({module(), atom(), list()})
  defp periodic_measurements do
    [
      # A module, function and arguments to be invoked periodically.
      # This function must call :telemetry.execute/3 and a metric must be added above.
      # {PeanutButterShoppeWeb, :count_users, []}
    ]
  end
end
