defmodule PeanutButterShoppe.Products do
  @moduledoc """
  Context module for peanut butter products
  """
  alias Ecto.Changeset
  alias PeanutButterShoppe.Products.Product
  alias PeanutButterShoppe.Repo

  @spec create(map()) :: {:ok, Product.t()} | {:error, Changeset.t(Product.t())}
  def create(attrs) do
    %Product{}
    |> Product.changeset(attrs)
    |> Repo.insert()
  end

  @spec list() :: list(Product.t())
  def list do
    Repo.all(Product)
  end

  def find(product_id) do
    Repo.get(Product, product_id)
  end
end
