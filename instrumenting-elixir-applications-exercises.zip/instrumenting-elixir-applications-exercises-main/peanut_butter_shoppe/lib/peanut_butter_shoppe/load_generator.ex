defmodule PeanutButterShoppe.LoadGenerator do
  @moduledoc """
  Exposes a function to generate load against the
  Peanut Butter Shoppe web app running locally.

  This will assist in generating enough request and load
  against the system that we will be able to see some
  decent percentile breakdown metrics.
  """

  @paths [
    "/",
    "/users/log_in",
    "/users/register"
  ]

  @doc """
  Generates load by executing requests against the Phoenix app.
  """
  @spec run(pos_integer()) :: :ok
  def run(number_of_requests \\ 1000) do
    1..number_of_requests
    |> Task.async_stream(
      fn _ ->
        path = Enum.random(@paths)
        Req.get!("http://localhost:4000#{path}")
      end,
      timeout: :timer.minutes(2),
      on_exit: :kill
    )
    |> Stream.run()
  end

  @doc """
  Generates memory pressure against the Virtual Machine
  """
  @spec stress_memory(pos_integer()) :: :ok
  def stress_memory(count \\ 150_000) do
    1..count
    |> Task.async_stream(
      fn n ->
        String.duplicate("String :-D", n)
      end,
      timeout: :timer.minutes(2),
      on_exit: :kill
    )
    |> Stream.run()
  end
end
