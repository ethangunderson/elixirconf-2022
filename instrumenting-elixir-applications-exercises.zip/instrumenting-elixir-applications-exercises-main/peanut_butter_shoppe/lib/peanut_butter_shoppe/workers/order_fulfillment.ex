defmodule PeanutButterShoppe.Workers.OrderFulfillment do
  use Oban.Worker, queue: :order_fulfillment

  alias PeanutButterShoppe.Orders
  alias PeanutButterShoppe.Orders.Order

  @impl Oban.Worker
  def perform(%Oban.Job{args: %{"id" => order_id}}) do
    with %Order{} = order <- Orders.get(order_id),
         {:ok, %Order{}} <- Orders.update(order, %{status: :processed}) do
      :ok
    else
      reason ->
        {:discard, "Order fulfillment failed: #{inspect(reason)}"}
    end
  end
end
