defmodule PeanutButterShoppe.Mailer do
  use Swoosh.Mailer, otp_app: :peanut_butter_shoppe
end
