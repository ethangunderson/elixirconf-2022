defmodule PeanutButterShoppe.Orders do
  @moduledoc """
  Context module for working with peanut butter orders.
  """
  alias PeanutButterShoppe.Orders.Order
  alias PeanutButterShoppe.Repo
  alias PeanutButterShoppe.Workers.OrderFulfillment

  import Ecto.Query

  @spec submit(map()) :: {:ok, Order.t()} | {:error, Ecto.Changeset.t()}
  def submit(attrs) do
    %Order{}
    |> Order.changeset(attrs)
    |> then(&add_random_failure/1)
    |> tap(&enqueue_for_fulfillment/1)
  end

  @spec update(Order.t(), map()) :: {:ok, Order.t()} | {:error, Ecto.Changeset.t()}
  def update(order, attrs) do
    order
    |> Order.changeset(attrs)
    |> Repo.update()
  end

  @spec get(id :: pos_integer()) :: Order.t() | nil
  def get(order_id) do
    Repo.get(Order, order_id)
  end

  @spec get_orders_by_user_id(id :: pos_integer()) :: list(Order.t())
  def get_orders_by_user_id(user_id) do
    Repo.all(from(o in Order, where: o.user_id == ^user_id))
  end

  @spec enqueue_for_fulfillment({:ok, Order.t()} | {:error, Ecto.Changeset.t()}) ::
          {:ok, Oban.Job.t() | {:error, Ecto.Changeset.t()}} | :ok
  defp enqueue_for_fulfillment({:ok, order}) do
    %{id: order.id}
    |> OrderFulfillment.new()
    |> Oban.insert()
  end

  defp enqueue_for_fulfillment(_), do: :ok

  @spec add_random_failure(Ecto.Changeset.t()) :: {:ok, Order.t()} | {:error, Ecto.Changeset.t()}
  defp add_random_failure(changeset) do
    if :rand.uniform(10) == 1 do
      {:error, Ecto.Changeset.add_error(changeset, :status, "marked as failed")}
    else
      Repo.insert(changeset)
    end
  end
end
