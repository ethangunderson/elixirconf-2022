defmodule PeanutButterShoppe.Orders.Order do
  @moduledoc """
  Order schema module
  """
  use Ecto.Schema
  import Ecto.Changeset

  alias PeanutButterShoppe.Accounts.User

  @type t() :: %__MODULE__{}

  schema "orders" do
    field :status, Ecto.Enum, values: [:pending, :processed], default: :pending
    belongs_to :user, User
  end

  @spec changeset(t(), map()) :: Ecto.Changeset.t()
  def changeset(order, params) do
    order
    |> cast(params, [:user_id, :status])
    |> validate_required([:user_id])
  end
end
