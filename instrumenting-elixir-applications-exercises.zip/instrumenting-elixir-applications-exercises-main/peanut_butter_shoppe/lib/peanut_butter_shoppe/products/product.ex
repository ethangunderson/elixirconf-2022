defmodule PeanutButterShoppe.Products.Product do
  @moduledoc """
  Schema module for peanut butter products
  """

  use Ecto.Schema

  import Ecto.Changeset

  schema "products" do
    field :name, :string
    field :description, :string
    field :list_price, :integer
    field :image_name, :string
  end

  @type t() :: %__MODULE__{}

  @spec changeset(t(), map()) :: Ecto.Changeset.t(t())
  def changeset(product, attrs \\ %{}) do
    product
    |> cast(attrs, ~w(name description list_price image_name)a)
    |> validate_required(~w(name list_price image_name)a)
  end
end
