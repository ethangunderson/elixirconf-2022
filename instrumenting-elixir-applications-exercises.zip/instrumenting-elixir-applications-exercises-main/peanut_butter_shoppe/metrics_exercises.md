The following exercises are meant to be worked on in pairs or small groups. We are tasked with building out instrumentation for our newest client, the Peanut Butter Shoppe. We will be working with Telemetry events emitted by core libraries like Phoenix and Ecto, as well as emitting our own custom events from the application itself to build out a rich set of metrics that can help us see exactly what is going on in the application. 

To build out our metrics, we're going to need a suite of tools: Statsd, Graphite, and Grafana. We have provided a docker-compose.yml file that will spin up these services for you. Make sure you are in the `peanut_butter_shoppe` root directory and run `docker-compose up -d`. Verify that you can access Grafana, which is the tool we'll use for visualizing our metrics, at [localhost:3000](localhost:3000). We'll also need to do some minor setup work once you have pulled up the Grafana UI

### Setting Up Grafana with a Graphite DataSource

1. Login to Grafana using the default credentials (username: `admin`, password: `admin`)
2. Hover over the Gear (settings) icon on the bottom left once you are logged in and click on "Data sources" in the menu that pops up.
3. Click on the "Graphite" data source
4. Under the "HTTP" options, fill out the URL field with `http://graphite:8080`
5. Scroll to the bottom and select "Save & test"
6. Click on the "Explore" option. 
7. Verify that the data source setup was successful by graphing some of the default statsd metrics: 
    - In the "Series" field in Explorer, click on "select metric". You should see `statsd` as an option. Click on that. Click on "select metric" again and click on the "*" option. 
    - You should now see a graph rendered. If so, your setup has been successful.
8. We have provided a skeleton Grafana dashboard. As you work through the exercises below, the visualizations will begin to populate incrementally as we add more and more metrics to our application. First, we have to import the dashboard:
    - On the left-hand navigation bar in Grafana, there is a "Dashboards" icon (represented by four squares/panels). Hover over that icon and click on the "+ Import" option that pops up
    - In the "Import" menu, click on "Upload JSON file". When prompted, upload the `dashboard.json` file from the root directory of the `peanut_butter_shoppe`.
    - Click "Load". You should now see a Dashboard with several panels. Let's work through the exercises below to begin populating them with metrics data.

# EXERCISES

### Note: Each Section below will contain at least 1 mandatory exercise. Do at least the first exercise in each section. Exercises marked as "Bonus" can be skipped over on the first pass and you can come back to these time allowing. If we are unable to complete all of the "Bonus" exercises, we highly recommend completing them on your own after the training. 

## Section 1: Default VM Metrics Exercises

For this section, please open the file `lib/peanut_butter_shoppe_web/telemetry.ex`. Take a moment to read through the provided skeleton code there, paying particular attention to the `metrics/0` function. As we work through these exercises, we will build a full suite of metrics and ship them to Statsd, which will allow us to visualize all of those metrics in Grafana.

1. Let's start with VM-level metrics. By virtue of running the `:telemetry_poller` library, we can listen for some [default VM measurements](https://hexdocs.pm/telemetry_poller/readme.html) without needing to execute any Telemetry events ourselves. One of the most critical metrics we want to monitor is the total amount of memory allocated by the BEAM. Let's create a metric for that:
    - The poller provides us with a `[:vm, :memory]` Telemetry event, which provides measurements from [`:erlang.memory/0,1`](https://www.erlang.org/doc/man/erlang.html#memory-0). We want to create a metric from the `total` measurement on the `[:vm, :memory]` event, which represents the total amount of memory allocated by virtual machine. Inside of the `vm_metrics/0` private function, use the [`last_value`](https://hexdocs.pm/telemetry_metrics/Telemetry.Metrics.html#last_value/2) function from `Telemetry.Metrics` to create this metric.
    - On the `last_value` metric we just defined, let's convert our units from `byte` to `kilobyte`. __NOTE__: To do this, it will be useful to read the "Unit Conversion" section from the Telemetry.Metrics documentation [here](https://hexdocs.pm/telemetry_metrics/Telemetry.Metrics.html#module-converting-units)
    - Once you have the metric defined, start up the server in an iex session: `iex -S mix phx.server`. Visit the homepage at [localhost:4000](localhost:4000). 
    - Now let's pop open Grafana at [localhost:3000](localhost:3000) and look at the dashboard uploaded during the setup. You should now see some values displaying in the "Total BEAM Memory Usage" and "VM Memory Usage Breakdown" panels.
    - Let's put our memory usage under a little stress. In your iex session, run `LoadGenerator.stress_memory()`. As this function runs, we will generate a spike in memory usage by building larger and larger strings in memory. We should see this manifest in our graph in Grafana, so monitor your memory graph as this function runs.
2. [__OPTIONAL__] Now let's flush out or memory metrics with a more granular look at where and why memory is allocated. The `[:vm, :memory]` event provides more granular measurements than just the overall total memory allocated by the VM. Let's add `last_value` metrics for the following as well:
    - The amount of memory allocated for processes by looking at the `processes` measurement
    - The amount of memory allocated for binaries by looking at the `binary` measurement
    - The same for atoms by looking at the `atom` measurement
    - ETS memory allocated by looking at the `ets` measurement. 
3. [__OPTIONAL__] Add a metric for the total number of processes running on the BEAM. We will use the `[:vm, :system_counts]` Telemetry event for this metric. You can find the measurements provided by this event [here](https://hexdocs.pm/telemetry_poller/telemetry_poller.html#module-system-counts).
4. [__OPTIONAL__] Add another metric for the total run queue lengths on the VM as well. We will rely on the `[:vm, :total_run_queue_lengths]` Telemetry event for this metric. Available measurements can be found [here](https://hexdocs.pm/telemetry_poller/telemetry_poller.html#module-total-run-queue-lengths).

## Section 2: Phoenix Metrics Exercises
Next, let's move on to creating metrics out of the Telemetry events provided by Phoenix. Add these metrics under the `phoenix_metrics/0` private function.

1. Let's get a count of the number of requests coming into the system. To do this, let's hook into the `[:phoenix, :endpoint, :start]` event. Make sure to use the right kind of [metric](https://hexdocs.pm/telemetry_metrics/Telemetry.Metrics.html#module-metrics) for a raw count of events. 
    - _NOTE_: Since this is a pure count metric, let's name this metric "phoenix.endpoint.start.count". 
2. Now let's really get a glimpse into system health by creating a summary metric capturing the duration of requests into the system:
    - Using the `[:phoenix, :endpoint, :stop]` Telemetry event, create a summary metric that looks at the `duration` measurement.
    - Let's convert our units from the `:native` unit to `:millisecond`.
    - Restart your Telemetry process by running `PeanutButterShoppeWeb.Telemetry.restart()`.
    - Now let's generate some load against the system to make sure these metrics are working. In iex, run `LoadGenerator.run(5_000)`, which will fire off 5,000 requests against the Peanut Butter Shoppe app. Now pop open your Grafana dashboard and take a look at the "Latencies" panel where you should see data flowing in.
3. [__OPTIONAL__] Now that we have a counter for the total number of requests coming into the system, let's get a more granular view of which specific routes are being hit. Create another counter metric called "phoenix.endpoint.start.count_by_path". We will need some new options from `Telemetry.Metrics` to make this happen. You'll want to review the `tag_values` and `tags` options found [here](https://hexdocs.pm/telemetry_metrics/Telemetry.Metrics.html#module-metrics)
    - Use the `tag_values` option. In the tag_value function, take the `conn` provided in the metadata of the `[:phoenix, :endpoint, :stop]` event and combine the `conn.method` and `conn.request_path` in a string. Set this string as the value of a tag (map key) called `request`.
    - Use the `tags` option to pluck the `:request` tag we just defined.
    - Verify that the metric is working by restarting the Telemetry process: `PeanutButterShoppe.Telemetry.restart()`. Generate some load with `LoadGenerator.run()`, and view your Grafana dashboard to see a breakdown of requests coming in.
4. __DISCUSSION__: Take a look at the full list of Telemetry events provided by Phoenix [here](https://hexdocs.pm/phoenix/Phoenix.Logger.html). Talk through which of these events contain measurements you think will be helpful for monitoring your applications. Choose one or two and work with your partner or group to create metrics for them to further enrich our `phoenix_metrics` function. 

## Section 3: Ecto/DB Metrics Exercises
We'll move on to instrumenting metrics from Ecto now. 

1. One of the most important database metrics we want to know is how long are queries are taking. Ecto provides us with a Telemetry event `[:peanut_butter_shoppe, :repo, :query]`, with measurements on a number of key stats related to querying. The one we want to look at to begin with is the `:total_time` measurement, which represents the comprehensive amount of time it takes for Ecto to secure a database connection, execute a query, and decode data received from the database. 
    - Add a summary metric for the `total_time` measurement. 
    - Restart your Telemetry process and generate some more load against the system: `LoadGenerator.run(3000)`.
    - Look at the "Database Metrics" panel in your Grafana dashboard. Verify that you now see data coming in.
2. [__OPTIONAL__] Let's add some more granularity to our database metrics by adding a summary metric for each of the other measurements from the `[:peanut_butter_shoppe, :repo, :query]` event:
    - `:idle_time`
    - `:queue_time`
    - `:query_time`
    - `:decode_time`
    - Graph these in the Grafana Explorer along with the `total_time` measurement we added in the first step.
3. __DISCUSSION__: Take a look at the Ecto Telemetry docs [here](https://hexdocs.pm/ecto/Ecto.Repo.html#module-telemetry-events) and find the `metadata` map values Ecto provides for the `[_app, :repo, :query]` event. Discuss with your group which of these values in the metadata map you find to be useful and why. Choose one or two and create tags for them that you can then graph in Grafana.

## Section 4: Custom Business Metrics Exercises
Now that we've knocked out a good chunk of metrics that will give us insight into the health of the runtime, our web server, and our database, let's turn our attention to adding metrics about our business itself! 

The Peanut Butter Shoppe wants to track a count of all incoming orders in the system. We'll need to expand across a couple of files to put everything in place and get our business metrics in order. 

1. Open `lib/peanut_butter_shoppe_web/controllers/orders_controller.ex`. You will see that we have a `create/2` function that will attempt to submit an order. 
    - In the `{:ok, _}` clause of the case statement, let's execute our own Telemetry event. Call it `[:peanut_butter_shopper, :order_submitted]`.
    - Record the `system_time` as a measurement (we can use `:erlang.system_time/0`).
    - In the metadata map, record the `:status` as `success`
    - In the `{:error, _}` clause, execute the same Telemetry event, only this time set `:status` as `failed` in the metadata map.
2. Now let's go back to the `lib/peanut_butter_shoppe_web/telemetry.ex` file and scroll down to the provided `business_metrics/0` private function. 
    - Create a counter metric that tracks the number of orders submitted. Call the metric ""peanut_butter_shoppe.order_submitted.count".
    - Add a `tags` option to this metric that specifies the `[:status]` tag.
    - Restart your server, open localhost:4000, and submit a few orders.
    - In our Grafana dashboard, you should the "Total Orders Submitted" and "Order Status Breakdowns" panels populate with data. 
3. __DISCUSSION__: What other data points might be interesting to add to the `:order_submitted` event? 
## Section 5: Custom VM Metrics Exercises
We are well on our way to success now. We've instrumented some key business metrics and have a wide-ranging view of the health of our runtime too. Let's further the extent of the visibility into our system by supplementing our VM metrics with more data. We will do this by utilizing the `:telemetry_poller` and using some of Erlang's built-in functions that provide statistics and insights into the health of the virtual machine.

1. In `lib/peanut_butter_shoppe_web/telemetry.ex` under the provided `dispatch_measurements/0` function, we will execute a few of our own Telemetry events that provide more details about the health of the virtual machine. 
    - First, let's get the total amount of garbage collections. We can do this by running the following code: `{gcs, _, _} = :erlang.statistics(:garbage_collection)`. 
    - Let's also grab the total amount of reductions: `{reductions, _} = :erlang.statistics(:reductions)`.
    - Once we have these values, let's execute a Telemetry event called: `[:vm, :info]`, providing the garbage collections and reductions as measurements to the event.
    - Inside of the provided `supplemental_vm_metrics/0` function, create a `last_value` metric. Add one each for garbage collections and reductions. 
    - To wire this up, we will need to execute our Telemetry events on a schedule. The way to do this is to use the `:telemetry_poller`. We already have a `periodic_measurements/0` function at the bottom of the file. Inside of the list, add the MFA tuple: `{__MODULE__, :dispatch_measurements, []}`. This will invoke the Telemetry events we defined in `dispatch_measurements` on a 10 second interval. 
    - Verify that your metrics are flowing in. Open the Grafana dashboard and look at the Reductions and Garbage Collections panel at the bottom. These two data points should keep going up throughout the course of the virtual machine.
2. __DISCUSSION__: Erlang provides all sorts of tools that can give us insights into the health and state of the virtual machine. Take a look at the documentation for `:erlang.statistics/1` [here](https://www.erlang.org/doc/man/erlang.html#statistics-1) and discuss with your group some of the statistics you see as valuable and why. Choose a couple and add them as measurements to the Telemetry event we defined in 1. above.
3. [__OPTIONAL__] Erlang provides a module called `:cpu_sup` that supervises CPU load and utilization. We have already started that app in our supervision tree (`application.ex`) and can use the module's tools to get some insights into CPU load.
    - Inside of dispatch measurements, call `:cpu_sup.util/0` ([docs](https://www.erlang.org/doc/man/cpu_sup.html#util-0)). 
    - Let's put this under a separate Telemetry event called `[:vm, :utilization]`. Set the result of `:cpu_sup.util/0` as a measurement called `cpu_load`.
4. Let's enrich the `[:vm, :utilization]` event with some measurements from the Erlang schedulers. There is a `:scheduler` module ([docs](https://www.erlang.org/docs/24/man/scheduler.html#utilization-2)) that provides utility functions for getting insights into the scheduler utilization. 
    - Get a sample of the scheduler utilization in total by running the following code `[{:total, scheduler_util, _}|_] = :scheduler.utilization(:scheduler.sample(), :scheduler.sample())`. 
    - Provide this as a measurement in the `[:vm, :utilization]` event (let's call the measurement `:scheduler_utilization`). Set the value to `scheduler_util * 100` (a rough percentage of scheduler utilization).
    - Create `last_value` metrics for these data points in the `supplemental_vm_metrics` private function.
    - Take a look at your Grafana Dashboard to see these values flowing in.
5. __DISCUSSION__: Can you think of any other VM-level measurements you would like to monitor? If so, can you get them from any functions provided by Erlang (and/or Elixir itself)? If you think of some, try adding them to the supplemental_vm_metrics we have already defined. 


## Section 6: Periodic Metric Measurements
Let's close out these exercises by taking some periodic measurements (as we did with the supplemental VM metrics above), but this time to provide us some more metrics about our business itself. 

1. Note that in `PeanutButterShopper.Accounts`, there is a function called `online_user_count`. This function mimics a count of users online.
    - Inside of the `dispatch_business_measurements/0` function, execute a Telemetry event called `[:peanut_butter_shopper, :users]`. In the measurements map, pass the users online under an `online` key by invoking the `online_user_count/0` function.
    - Let's set this to run as one of our periodic measurements as well. You will need to call it as an MFA ({module, function, args}) tuple in the `periodic_measurements` function.
2. Create a metric that tracks this measurement in the list of `business_metrics` (the function) we have already defined. For now, let's use the `last_value` metric type. 
3. Restart your Telemetry process and take a look at your Grafana dashboard. You should see the number of users in the Users Online panel.
4. __DISCUSSION__: What are some other valuable metrics that businesses might want to capture on a periodic basis? Are there any that you can add (feel free to add mock calls like `online_user_count/0`) to the metrics we are capturing in the Peanut Butter Shoppe app? If so, add one or two now.