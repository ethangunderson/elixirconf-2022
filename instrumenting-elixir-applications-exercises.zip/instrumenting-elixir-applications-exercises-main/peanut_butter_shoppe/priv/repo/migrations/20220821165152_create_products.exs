defmodule PeanutButterShoppe.Repo.Migrations.CreateProducts do
  use Ecto.Migration

  def change do
    create table(:products) do
      add :name, :string
      add :description, :text
      add :list_price, :integer
      add :image_name, :string
    end
  end
end
