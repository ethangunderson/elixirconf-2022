# Script for populating the database. You can run it as:
#
#     mix run priv/repo/seeds.exs
#
# Inside the script, you can read and write to any of your
# repositories directly:
#
#     PeanutButterShoppe.Repo.insert!(%PeanutButterShoppe.SomeSchema{})
#
# We recommend using the bang functions (`insert!`, `update!`
# and so on) as they will fail if something goes wrong.
alias PeanutButterShoppe.Products

attrs = %{
  name: "Super Smooth",
  description:
    "If you love peanut butter, then you'll love this smooth and creamy peanut butter. It's the smoothest peanut butter ever! No chunks, no texture whatsoever - it's like butter!",
  list_price: 8,
  image_name: "SuperSmooth.png"
}

Products.create(attrs)

attrs = %{
  name: "Smooth & Creamy",
  description:
    "Whip up a pot of creamy, easy to make peanut butter. Our Smooth and Creamy Peanut Butter is packed with the good stuff: only one ingredient, peanuts. Oh, and also cream.",
  list_price: 8,
  image_name: "SmoothAndCreamy.png"
}

Products.create(attrs)

attrs = %{
  name: "Chunky",
  description:
    "Crunchy on the outside, creamy on the inside. Sure, like normal crunchy peanut butter, but amped to 11!",
  list_price: 11,
  image_name: "Chunky.png"
}

Products.create(attrs)

attrs = %{
  name: "Super Crunch",
  description:
    "Labeled a superhero of the peanut butter world, this peanut butter is everything but ordinary. For those who like a little pep in their step, this peanut butter delivers the goods. From its chunky texture to its robust flavor and sweet, smooth taste.",
  list_price: 10,
  image_name: "SuperCrunch.png"
}

Products.create(attrs)

attrs = %{
  name: "A jar of nuts",
  description:
    "We told our scientists to not come back until they created the crunchiest version of peanut butter that could ever exist. After years of toil, they returned with a jar of nuts. They are technically correct, which is the best form of correct.",
  list_price: 15,
  image_name: "JarOfNuts.png"
}

Products.create(attrs)
