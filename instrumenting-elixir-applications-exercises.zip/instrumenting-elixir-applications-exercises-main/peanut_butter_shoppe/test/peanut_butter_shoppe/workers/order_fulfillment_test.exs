defmodule PeanutButterShoppe.Workers.OrderFulfillmentTest do
  use PeanutButterShoppe.DataCase
  use Oban.Testing, repo: PeanutButterShoppe.Repo

  import PeanutButterShoppe.AccountsFixtures

  alias PeanutButterShoppe.Orders
  alias PeanutButterShoppe.Orders.Order
  alias PeanutButterShoppe.Repo
  alias PeanutButterShoppe.Workers.OrderFulfillment

  describe "perform/1" do
    setup do
      user = user_fixture()
      {:ok, order} = Orders.submit(%{user_id: user.id})

      {:ok, order: order}
    end

    test "toggles order status to processed", %{order: order} do
      assert :ok = perform_job(OrderFulfillment, %{id: order.id})

      assert %Order{status: :processed} = Repo.get(Order, order.id)
    end
  end
end
