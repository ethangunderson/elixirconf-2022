defmodule PeanutButterShoppe.OrdersTest do
  use PeanutButterShoppe.DataCase
  use Oban.Testing, repo: PeanutButterShoppe.Repo

  import PeanutButterShoppe.AccountsFixtures

  alias Ecto.Changeset
  alias PeanutButterShoppe.Orders
  alias PeanutButterShoppe.Orders.Order

  describe "submit/1" do
    test "creates an order with valid attributes and enqueus the order for fulfillment" do
      Oban.Testing.with_testing_mode(:manual, fn ->
        %{id: user_id} = user_fixture()

        assert {:ok, %Order{user_id: ^user_id, status: :pending} = order} =
                 Orders.submit(%{user_id: user_id})

        assert_enqueued(
          worker: PeanutButterShoppe.Workers.OrderFulfillment,
          args: %{id: order.id},
          queue: :order_fulfillment
        )
      end)
    end

    test "returns an error tuple if no user is present" do
      assert {:error, %Changeset{valid?: false}} = Orders.submit(%{})
    end
  end

  describe "update/2" do
    test "updates an existing order" do
      %{id: user_id} = user_fixture()
      {:ok, order} = Orders.submit(%{user_id: user_id})

      assert {:ok, %Order{status: :processed}} = Orders.update(order, %{status: :processed})
    end

    test "returns an error tuple when given invalid attributes" do
      %{id: user_id} = user_fixture()
      {:ok, order} = Orders.submit(%{user_id: user_id})

      assert {:error, %Changeset{valid?: false}} =
               Orders.update(order, %{status: :not_a_valid_status})
    end
  end

  describe "get/1" do
    test "returns an order if exists" do
      %{id: user_id} = user_fixture()
      {:ok, %{id: order_id}} = Orders.submit(%{user_id: user_id})

      assert %Order{id: ^order_id} = Orders.get(order_id)
    end

    test "returns nil when no matching order exists" do
      assert is_nil(Orders.get(1))
    end
  end

  describe "get_orders_by_user_id/1" do
    test "returns all orders for a user" do
      %{id: user_id} = user_fixture()
      {:ok, %{id: order_id}} = Orders.submit(%{"user_id" => user_id})

      assert [%Order{id: ^order_id}] = Orders.get_orders_by_user_id(user_id)
    end

    test "returns an empty list when no orders exist" do
      assert [] == Orders.get_orders_by_user_id(2)
    end
  end
end
