defmodule PeanutButterShoppe.ProductsTest do
  use PeanutButterShoppe.DataCase

  alias PeanutButterShoppe.Products
  alias PeanutButterShoppe.Products.Product

  @valid_attrs %{name: "Gif Peanut Butter", description: "Memes and peanut butter", list_price: 5}

  describe "create/1" do
    test "returns a product given valid attributes" do
      assert {:ok,
              %Product{
                name: "Gif Peanut Butter",
                description: "Memes and peanut butter",
                list_price: 5
              }} = Products.create(@valid_attrs)
    end

    test "requires name and list_price" do
      assert {:error, %Ecto.Changeset{valid?: false}} =
               Products.create(%{description: "this isn't required though."})
    end
  end

  describe "list/0" do
    test "returns all Product records" do
      {:ok, product} = Products.create(@valid_attrs)

      assert [^product] = Products.list()
    end
  end
end
