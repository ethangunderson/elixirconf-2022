defmodule PeanutButterShoppeWeb.PageViewTest do
  use PeanutButterShoppeWeb.ConnCase, async: true
end
