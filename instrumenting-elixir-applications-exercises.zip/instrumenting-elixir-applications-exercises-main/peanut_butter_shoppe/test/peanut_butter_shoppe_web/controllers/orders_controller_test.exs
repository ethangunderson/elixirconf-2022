defmodule PeanutButterShoppe.OrdersControllerTest do
  use PeanutButterShoppeWeb.ConnCase, async: true

  alias PeanutButterShoppe.Orders

  describe "POST /orders" do
    test "redirects to home page and sets flash when an order is successfully submitted",
         context do
      %{conn: conn} = register_and_log_in_user(context)
      order_submitted_conn = post(conn, Routes.orders_path(conn, :create), %{})

      assert redirected_to(order_submitted_conn) == Routes.page_path(conn, :index)
      assert get_flash(order_submitted_conn, :info) =~ "Order submitted successfully"
      assert [_ | _] = Orders.get_orders_by_user_id(order_submitted_conn.assigns.current_user.id)
    end

    test "redirects if user is not logged in", %{conn: conn} do
      order_conn = post(conn, Routes.orders_path(conn, :create), %{})

      assert redirected_to(order_conn) == Routes.user_session_path(conn, :new)
    end
  end
end
