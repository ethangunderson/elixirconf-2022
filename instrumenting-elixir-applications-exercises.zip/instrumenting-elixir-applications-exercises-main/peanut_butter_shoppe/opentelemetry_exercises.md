The following exercises are meant to be worked on in pairs or small groups. Using OpenTelemetry you will build up the instrumentation of your newest client, the peanut butter shoppe.

To get started you'll need to get the Phoenix app running. The following commands will install dependencies needed, setup the database and product seeds, and then start the Elixir application.

```
mix deps.get
mix ecto.setup
mix phx.server
```

`localhost:4000` will now server the Peanut Butter Shoppe web application.

To visualize trace data you will use a tool named Jaeger. A docker-compose file has been provided. Run `docker-compose up -d` to start the service and visit `localhhost:16686` to ensure that the system is working as expected.

## Exercise 1 - Phoenix Traces

The first step to instrumenting a Phoenix application is to create traces for requests. In
`lib/peanut_butter_shoppe_web/telemetry/phoenix.ex` you'll find the skeleton of a module to
handle some of Phoenix's Telemetry events. In order to properly instrument requests two different Telemetry events are required:

``` elixir
[:phoenix, :endpoint, :start]
[:phoenix, :router_dispatch, :start]
[:phoenix, :endpoint, :stop]
```

The module skeleton has code in place to attach functions to these events. There are several TODOs in the module that will guide you through leveraging these events to create spans.

With all of the TODOs complete, restart your server and visit localhost:4000. Then, go to Jaeger at http://localhost:16686. Change the search criteria and set the service to `PeanutButterShoppe` and search for all traces. You will see your Phoenix requests. 

Congrats! You're cooking with fire now.

Go ahead and click on a trace and explore around. Notice that when viewing a trace there is a list of `tags`. Those tags will contain the attributes set in the Telemetry handler code. __Group discussion__: So far we have the status code and the method, what else would be useful to set as a trace attribute?

## Exercise 2 - Ecto Traces
Now that there is a trace that represents the start and endpoints of a request, it's time to add more granularity. Since the peanut butter shoppe has a database, adding spans for database queries is the next logical place to add instrumentation. To accomplish that we can use Ecto Telemetry events.

Ecto has one Telemetry event that is executed when a query is completed. Since the event is _after_ the query is completed, you'll need to do some math and slightly clunky opening and closing of spans. Head to the `lib/peanut_butter_shoppe_web/telemetry/ecto.ex` and complete the TODOs.

When that's done, restart your server and request some pages. Back in Jaeger you'll see multiple spans for each trace. Yay! This is the first step in seeing not just the total duration of a request, but where that time is actually being spent.

## Exercise 3 - Function Traces

With Phoenix and Ecto instrument we are starting to get a picture of what our requests look like and where time is being spent. But it's not always going be third party libraries that need instrumentation. Our own code can be, and is often, the source of latency in requests and deserves just as much attention.

The next step is to use `Opentelemetry.Tracer.with_span` to wrap our function bodies in spans. Head to `PeanutButterShoppeWeb.ProductsController` and complete the TODO.

Afterwards, restart your server and view a few pages of the fine peanut butter offered by the shoppe. Head to Jaeger and view traces for the Operation `GET /products/:id`. You'll now see our new function being instrumented.

While this approach works, it has a few issues. Mainly the instrumentation code is detracting from the business logic of the function. When triaging or otherwise debugging code you'll always want the code to be as easy to read as possible. With that in mind, there's another OpenTelemetry package we can use to accomplish the goal of instrumenting our function without littering it with instrumentation code.

Head back to `PeanutButterShoppeWeb.ProductsController` and remove the call to `with_span`, but leaving the business logic. Replace the call to `require OpenTelemetry.Tracer, as: Tracer` with `use OpenTelemetryDecorator` and above the function `track_product_show_in_analytics` add `@decorate with_span()`. Restart your server, visit a few product pages, visit Jaeger, and you'll find that the function is being instrumented as expected.

## Exercise 4 - Trace Attributes

An important concept of tracing is the span attributes. Span attributes give a way for developers to provide context to the trace. A wide range of attributes will go a long way to ease triaging. As an example, the product show trace that we've been working on is recorded as `GET products/:id`. If this page were to start throwing errors, or having high latency, it might be useful to know what product is being viewed. Using `Tracer.set_attribute/2` in `PeanutButterShoppeWeb.ProductsController.show/2` set the products id as an attribute on the trace.

Being able to set trace attributes isn't limited to specific functions. Sometimes there is global context that can be useful. Head to `PeanutButterShoppeWeb.UserAuth.fetch_current_user/2`. Use the identified user to set a `user_id` attribute on the trace. __Group discussion__: What other global context attributes would be useful to set?

## Exercise 5 - External Request Spans

At some point in an application's life cycle there's a good chance that it will need to communicate with an external service. That could be anything from another service that you are responsible for to a third party completely. However, one thing will be certain, and that those services will eventually have issues. Increased latency or strait up downtime can negatively impact your systems, so it's important to add instrumentation.

In `PeanutButterShoppeWeb.ProductsController.track_product_show_in_analytics/1` you'll see that we're using an HTTP library named `Req` to execute an http request.There are a few options for how we can instrument this request. The most obvious way is to wrap the call to `Req.request` in a span. While that works, it also means that we have to do that every time we make an http request. That's no fun.

Luckily we have another option. Under the hood, Req uses an HTTP library named Finch. Finch has its own Telemetry events. Instrumenting with Finch Telemetry will allow us to write one implementation that every Req request can benefit from. Head to `PeanutButterShoppeWeb.Telemetry.Finch` and complete the TODOs.

Afterwards, reload your server, visit the product page, and look for your updated http request spans on product traces. You'll see that the span for `track_product_show_in_analytics/1` now has a child span of `HTTP Request`!

The name HTTP Request leaves a little to be desired. You have to click into the span to see what service is actually being called. It would be much better to update the span name to be the HTTP method and domain being requested. Go ahead and do that now.

## Exercise 6 - Crossing the Process Boundary

After adding instrumentation to `track_product_show_in_analytics` we can see that it's not exactly performant. Worse, we're not even doing anything with the response. We can improve the performance of this page by throwing the HTTP request into a Task. Replace the existing function body with the code below.

``` elixir
Task.start(fn -> 
  Req.request(method: :get, url: "https://httpstat.us/200?sleep=#{:rand.uniform(5000)}")
end)
```

Now, reload your server, visit a product page. The page will load much faster now and be more consistent. However, go look at the trace for this request. You'll notice that we lost the span for the http request. Oh no!

This is due to an implementation detail of OpenTelemetry. OpenTelemetry uses the process dictionary to accumulate span data. By opening a Task, we've started a new process. That process doesn't have any of the existing span data from the Phoenix request.

There are two ways we can work around this pickle. The first way is to explicitly get the current context outside of the Task, and use it in the task. An example would look something like this:

``` elixir
span_ctx = OpenTelemetry.Tracer.start_span("child")
ctx = OpenTelemetry.Ctx.get_current()

task =
  Task.async(fn ->
    OpenTelemetry.Ctx.attach(ctx)
    OpenTelemetry.Tracer.set_current_span(span_ctx)
    # do work here

    OpenTelemetry.Tracer.end_span(span_ctx)
  end)

_result = Task.await(task)
```
However, for our Finch example, we don't have a way to inject the current context into Finch's Telemetry. OpenTelemetry has a solution for this. It's called the `OpentelemetryProcessPropagator`. Its job is to provide us with helper functions to propagate trace context across process boundaries.

In the Finch Telemetry module, change the `parent_context` function call to `parent_context = OpentelemetryProcessPropagator.fetch_parent_ctx()`. This is a neat little function that will inspect the parent process' process dictionary and look for trace context. `OpentelemetryProcessPropagator` also has functions that allow you to search up the ancestor tree. Feel free to look at the hex docs to see what's available. https://hexdocs.pm/opentelemetry_process_propagator/OpentelemetryProcessPropagator.html#content

Reload, visit product page, look at the Jaeger traces. You'll see that the span for our HTTP request is back, and the page is still performant! Win win.

These techniques come into play frequently in our experience. One of Elixir's strengths is the developer ergonomics of spinning up cheap processes and offloading work from the main request thread. Being able to instrument them effectively is a key skill to have.

## Exercise 7 - Oban Traces

Similar to Phoenix, Oban provides a slew of Telemetry events that we can use to instrument our asynchronous workloads. Also similar to Phoenix events, an Oban job starting and stopping represents the bounds of a trace. Head to `PeanutButterShoppeWeb.Telemetry.Oban` and complete the TODOs.

Afterwards, visit a product page and purchase a jar of peanut butter. The flavor is up to you! Then, visit Jaeger again and view traces for the operation `Oban PeanutButterShoppe.Workers.OrderFulfillment`. You'll notice that we have traces as well as the existing Ecto telemetry spans. This is where the multiplying power of Telemetry becomes more evident. We've added a new entry point to the platform and immediately get value from existing Telemetry integrations and span data. As the system matures this will happen more and more.
